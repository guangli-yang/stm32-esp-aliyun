#include "stm32f10x.h" 
#include "timer.h" 
#include "dht11.h"
#include "wifi.h"
unsigned char Usart1_dht11 = 0;
unsigned int T = 0;
void	TIM4_Init(uint32_t per,uint32_t psc);

void	TIM4_Init(uint32_t per,uint32_t psc){
	
	  NVIC_InitTypeDef NVIC_InitStructure;
		TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
				
		TIM_TimeBaseStructure.TIM_Period = per;//װ��ֵ
		TIM_TimeBaseStructure.TIM_Prescaler = psc;// ��Ƶ��������
		TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
		TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
		TIM_TimeBaseInit(TIM4, & TIM_TimeBaseStructure);
	 
	  NVIC_InitStructure.NVIC_IRQChannel =  TIM4_IRQn ;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0 ;//��ռ���ȼ�1
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;		//�����ȼ�1
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
		NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���
			
		TIM_ITConfig(TIM4, TIM_IT_Update , ENABLE );
	
		TIM_Cmd(TIM4, ENABLE);
		
	}
void TIM3_PWM_Init(u16 arr,u16 psc)
{  
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);	//?????3??
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB  | RCC_APB2Periph_AFIO, ENABLE);  //??GPIO???AFIO????????
	
	GPIO_PinRemapConfig(GPIO_PartialRemap_TIM3, ENABLE); //Timer3?????  TIM3_CH2->PB5    
 
   //????????????,??TIM3 CH2?PWM????	GPIOB.5
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5; //TIM_CH2
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  //??????
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);//???GPIO
 
   //???TIM3
	TIM_TimeBaseStructure.TIM_Period = arr; //???????????????????????????
	TIM_TimeBaseStructure.TIM_Prescaler =psc; //??????TIMx??????????? 
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //??????:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //TIM??????
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); //??TIM_TimeBaseInitStruct?????????TIMx???????
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //???????:TIM????????2
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //??????
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //????:TIM??????? TIM_OCPolarity_Low
 
 
	TIM_OC2Init(TIM3, &TIM_OCInitStructure);  //??T??????????TIM3 OC2

	TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);  //??TIM3?CCR2????????
 
	TIM_Cmd(TIM3, ENABLE);  //??TIM3

}

void TIM4_IRQHandler(void)                	//����1�жϷ������
{

if(TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET)  //�����ж�
	{
			if(T<2000){
			T++;}
			else{T=0;
		 Usart1_dht11= 1;}
		
    GPIOE->ODR^= GPIO_Pin_5;
		TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
	}
}	
