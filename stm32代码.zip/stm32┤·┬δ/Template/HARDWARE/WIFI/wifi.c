#include "wifi.h"
#include "stdio.h"
#include "string.h"
#include <stdbool.h>
#include "usart.h"
#include "stdlib.h"
#include "led.h"
#include "stm32f10x.h"                  // Device header
#include "electric.h"
#include "beep.h"
#include "timer.h"
unsigned char j = 50;
void WIFI_Init(void)
{
	WIFI_Rst();
	Setting_Connect_Work("1");
	wait_OK();
	
	Login_URL();
	wait_OK();
	
	WIFI_Connect("\"HONOR-x3pro\"","\"zxcvbnmm\"");
	wait_OK();
	
	USER_Connect();
	wait_OK();
	
	Client_Connect();
	wait_OK();
	
	Connect_Aliyun_Server();
	wait_OK();
	
	Client_Subscribe();
	wait_OK();
}

/*********************����WIFIģ��*****************************/
void WIFI_Rst(void)
{
	USART1TxStr("����ģ��...\r\n"); 
	USART2TxStr("AT+RST\r\n");
	Delay_Ms(1000);           //WIFI������Ҫ�¼�
	Delay_Ms(1000);
	Delay_Ms(1000);
	Delay_Ms(1000);
	Delay_Ms(1000);
	Delay_Ms(1000);
	CLR_Buf2();               //�������2���ջ���
	Flag_usart2_receive_OK = 0;
}

/*******************����WIFI����ģʽ****************************
/
/			1 STAģʽ
/			2 APģʽ
/			3 STA��APģʽ
/
**************************************************************/
void Setting_Connect_Work(char *type)
{
	

	char wifi_mode_buf[13] = {"AT+CWMODE=x\r\n"};
	wifi_mode_buf[10] = *type;
	USART1TxStr("���ù���ģʽ...\r\n");
	USART1TxStr(wifi_mode_buf);
	USART2TxStr(wifi_mode_buf);

}

/*********************��¼��ַ******************************/
void Login_URL(void)
{	
	char login_url[100] = {"AT+CIPSNTPCFG=1,8,\"ntp1.aliyun.com\"\r\n"};
	USART1TxStr("���Ӱ����Ʒ�����...\r\n");
	USART1TxStr(login_url);
	USART2TxStr(login_url);
}

/*********************����WIFI******************************/
void WIFI_Connect(char *name,char *password)
{
	char wifi_connect_buf[100] = {"AT+CWJAP="};
	strcat(wifi_connect_buf,name);
	strcat(wifi_connect_buf,",");
	strcat(wifi_connect_buf,password);
	strcat(wifi_connect_buf,"\r\n");
	USART1TxStr("������֪WiFi...\r\n");
	USART1TxStr(wifi_connect_buf);
	USART2TxStr(wifi_connect_buf);
}

/*********************�û��豸����*******************************/
void USER_Connect(void)
{
	char user_connect_buf[200] = {"AT+MQTTUSERCFG=0,1,\"NULL\",\"y0001&a1vrRbrB2Vv\",\"CE581AD7619D41F3595A6C4E0E19D6B1FDBD83C8\",0,0,\"\"\r\n"};
	USART1TxStr("�û��豸����...\r\n");
	USART1TxStr(user_connect_buf);
	USART2TxStr(user_connect_buf);
}

/*********************���ӿͻ���*******************************/
void Client_Connect(void)
{
	char client_connect_buf[100] = {"AT+MQTTCLIENTID=0,\"12345|securemode=3\\,signmethod=hmacsha1|\"\r\n"};
	USART1TxStr("���ӿͻ���...\r\n");
	USART1TxStr(client_connect_buf);
	USART2TxStr(client_connect_buf);
}

/*********************���Ӱ����Ʒ�����*************************/

void Connect_Aliyun_Server(void)
{
	char connect_server_buf[100] = {"AT+MQTTCONN=0,\"a1vrRbrB2Vv.iot-as-mqtt.cn-shanghai.aliyuncs.com\",1883,1\r\n"};
	USART1TxStr("���Ӱ����Ʒ�����...\r\n");
	USART1TxStr(connect_server_buf);
	USART2TxStr(connect_server_buf);
}

/*********************�ͻ��˶���*************************/
void Client_Subscribe(void)
{
	char client_subscribe_buf[100] = {"AT+MQTTSUB=0,\"/sys/a1vrRbrB2Vv/y0001/thing/service/property/set\",1\r\n"};
	USART1TxStr("�ͻ��˶�����Ϣ...\r\n");
	USART1TxStr(client_subscribe_buf);
	USART2TxStr(client_subscribe_buf);
	
}

/*********************�豸���ϱ�*************************/
void Client_Pubscribe(float temp)
{ 
	char str[120];
	
	char client_Pubscribe_buf[100] = {"AT+MQTTPUB=0,\"/sys/a1vrRbrB2Vv/y0001/thing/event/property/post\",\"{\\\"params\\\":{\\\"temperature0\\\""};
	USART1TxStr("�豸���ϱ���Ϣ..\r\n");
	CLR_Buf2();
	sprintf (str,":%0.1f}}\"",temp);
	strcat(client_Pubscribe_buf,str);
	strcat(client_Pubscribe_buf,",0,0\r\n");
	 
	USART1TxStr(client_Pubscribe_buf);
	USART2TxStr(client_Pubscribe_buf);
	wait_OK();
	
}

void Client_Pubscribe1(float humi)
{ 
	char str[120];
	
	char client_Pubscribe_buf[100] = {"AT+MQTTPUB=0,\"/sys/a1vrRbrB2Vv/y0001/thing/event/property/post\",\"{\\\"params\\\":{\\\"Humidity\\\""};
	USART1TxStr("�豸���ϱ���Ϣ..\r\n");
	CLR_Buf2();
	sprintf (str,":%0.1f}}\"",humi);
	strcat(client_Pubscribe_buf,str);
	strcat(client_Pubscribe_buf,",0,0\r\n");
	 
	USART1TxStr(client_Pubscribe_buf);
	USART2TxStr(client_Pubscribe_buf);
	wait_OK();
	
}

void Client_Pubscribe2(float adcx)
{ 
	char str[120];
	
	char client_Pubscribe_buf[100] = {"AT+MQTTPUB=0,\"/sys/a1vrRbrB2Vv/y0001/thing/event/property/post\",\"{\\\"params\\\":{\\\"LightLux\\\""};
	USART1TxStr("�豸���ϱ���Ϣ..\r\n");
	CLR_Buf2();
	sprintf (str,":%0.1f}}\"",adcx);
	strcat(client_Pubscribe_buf,str);
	strcat(client_Pubscribe_buf,",0,0\r\n");
	 
	USART1TxStr(client_Pubscribe_buf);
	USART2TxStr(client_Pubscribe_buf);
	wait_OK();
	
}



void Client_Pubscribe_mode(int modex)
{ 
	char str[120];
	char str0[120];
	
	char client_Pubscribe_buf[100] = {"AT+MQTTPUB=0,\"/sys/a1vrRbrB2Vv/y0001/thing/event/property/post\",\"{\\\"params\\\":{\\\"mode"};
	USART1TxStr("�豸���ϱ���Ϣ..\r\n");
	CLR_Buf2();
  sprintf (str0,"%d\\\"",modex);
	sprintf (str,":1}}\"");
	strcat(client_Pubscribe_buf,str0);
	strcat(client_Pubscribe_buf,str);
	strcat(client_Pubscribe_buf,",0,0\r\n");
	 
	USART1TxStr(client_Pubscribe_buf);
	USART2TxStr(client_Pubscribe_buf);
	wait_OK();
}	


/*********************�豸���ϱ�����*************************/
void wait_SUB(void)
{	
	int len;
  int a;
	char *ret[9] ;
	char str1[10],str2[10],str3[10],str4[10],str5[10],str6[10],str7[10],str8[10],str9[10];
	bool val[9];
	len = strlen(USART2_RX_BUF);//�ж��Ƿ���յ�����
	if(len>10)
		{
	  USART1TxStr(USART2_RX_BUF);//������Ϣ��ӡ
	  ret[0]=strstr(USART2_RX_BUF,"VehACSwitch");   //ƥ�����ݹؼ���     �յ�
	  ret[1]=strstr(USART2_RX_BUF,"TVswitch");      //ƥ�����ݹؼ���     ���ӻ�
		ret[2]=strstr(USART2_RX_BUF,"heaterswitch");  //ƥ�����ݹؼ���     ��ˮ��	
		ret[3]=strstr(USART2_RX_BUF,"WashingSwitch"); //ƥ�����ݹؼ���		 ϴ�»�	
		ret[4]=strstr(USART2_RX_BUF,"LockState");     //ƥ�����ݹؼ���     ����
	  ret[5]=strstr(USART2_RX_BUF,"LightSwitch1");  //ƥ�����ݹؼ���     ������
		ret[6]=strstr(USART2_RX_BUF,"LightSwitch0");  //ƥ�����ݹؼ���     ���ص�	
		ret[7]=strstr(USART2_RX_BUF,"Buzzer");        //ƥ�����ݹؼ���		 ������ 
		ret[8]=strstr(USART2_RX_BUF,"mode");        //ƥ�����ݹؼ���	 	 �龳ģʽ	
/***********************************************/		//�յ�
			if(ret[0]!=NULL){
			    
					str1[0]=*(ret[0]+13);
					//str[1]=*(ret+13);
					str1[1]='\0';
					val[0]= atoi(str1);
						printf("�յ��� %d",val[0]);
	      		
					 if(val[0])
					 { relay1_on();}
					 	else
      			{relay1_off();}
					}
/***********************************************/			//	���ӻ�				
				if(ret[1]!=NULL)
			    {
					str2[0]=*(ret[1]+10);
					//str[1]=*(ret+13);
					str2[1]='\0';
					val[1]= atoi(str2);
						printf("���ӻ��� %d",val[1]);
	      		
					 if(val[1])
					 { relay2_on();}
					 	else
      			{relay2_off();}		
					}
/***********************************************/			//��ˮ��						
						if(ret[2]!=NULL)
			    {
					str3[0]=*(ret[2]+14);
					//str[1]=*(ret+13);
					str3[1]='\0';
					val[2]= atoi(str3);
						printf("��ˮ��:��%d" ,val[2]);
	      	
					 if(val[2])
					 { relay3_on();}
					 	else
      			{relay3_off();}		
						}	
/***********************************************/				//ϴ�»�			
						if(ret[3]!=NULL)
			    {
					str4[0]=*(ret[3]+15);
					//str[1]=*(ret+15);
					str4[1]='\0';
					val[3]= atoi(str4);
						printf("ϴ�»��� %d" ,val[3]);
	      	
					 if(val[3])
					 { relay4_on();}
					 	else
      			{relay4_off();}		
					}		
/***********************************************/			// ����

			if(ret[4]!=NULL){
			    
					str5[0]=*(ret[4]+11);
					//str[1]=*(ret+13);
					str5[1]='\0';
					val[4]= atoi(str5);
					printf("������ %d",val[4]);
	 
	      	
					 if(val[4])
					 { 
						 for( j=50;j<=250;j++){
						 TIM_SetCompare2(TIM3, j);
						 Delay_Ms(25);}
					 }
					 	else
      			{
						  for( j=250;j>=51;j--){
						  TIM_SetCompare2(TIM3, j);}
						  Delay_Ms(25);
						}
					}
/***********************************************/				// ������				
				if(ret[5]!=NULL)
			    {
					str6[0]=*(ret[5]+14);
					//str[1]=*(ret+13);
					str6[1]='\0';
					val[5]= atoi(str6);
						printf("�����ƣ� %d",val[5]);
	      		
					 if(val[5])
					 { LightSwitch1_ON;}
					 	else
      			{LightSwitch1_OFF;}		
					}
/***********************************************/					//���ص�				
						if(ret[6]!=NULL)
			    {
					str7[0]=*(ret[6]+14);
					//str[1]=*(ret+13);
					str7[1]='\0';
					val[6]= atoi(str7);
						printf("���صƣ���%d",val[6]);
	      	
					 if(val[6])
					 { LightSwitch0_ON;}
					 	else
      			{LightSwitch0_OFF;}		
						}	
/***********************************************/					//������ 	
						if(ret[7]!=NULL)
			    {
					str8[0]=*(ret[7]+8);
					//str[1]=*(ret+15);
					str8[1]='\0';
					val[7]= atoi(str8);
						printf("�������� %d" ,val[7]);
	      	
					 if(val[7])
					 { BEEP_ON;} 
					 	else
      			{BEEP_OFF;}		
					}		
/***********************************************/					//�龳	
						if(ret[8]!=NULL)
			    {
					str9[0]=*(ret[8]+6);
					//str[1]=*(ret+15);
					str9[1]='\0'; 
					a= atoi(str9);
						printf("�龳ģʽ��%d" ,a);
	      	
					switch(a){
						case 0:		
					      BEEP_ON;
					     	Delay_Ms(1000);
						    BEEP_OFF;
						Client_Pubscribe_mode(0);
					 
						
						    break;
						
						case 1:		
					      BEEP_ON;
					     	Delay_Ms(1000);
						    BEEP_OFF;
						 Client_Pubscribe_mode(1);
						    break;
						
						case 2:		
					      BEEP_ON;
					     	Delay_Ms(1000);
						    BEEP_OFF;
						Client_Pubscribe_mode(2);
						    break;
						
						case 3:		
					      BEEP_ON;
					     	Delay_Ms(1000);
						    BEEP_OFF;
							Client_Pubscribe_mode(3);
						    break;
      			
            case 4:		
					      BEEP_ON;
					     	Delay_Ms(1000);
						    BEEP_OFF;
						Client_Pubscribe_mode(4);
						    break;	
						default:
                break;							
				           	}		
					
/***********************************************/	
				}		
	 CLR_Buf2();  //�������2���ջ���
	  }
}

void wait_OK(void)
{	
	while(!Flag_usart2_receive_OK);//�ȴ����յ�OK�ַ���
	Flag_usart2_receive_OK = 0;
	USART1TxStr("�ɹ�\r\n\n" );
	CLR_Buf2();     //�������2���ջ���
}
