#ifndef __LED_H
#define __LED_H
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
void LED_Init(void);

#define LED_PORT GPIOB
#define LED_PIN GPIO_Pin_5;

#define LED0_ON GPIO_ResetBits(LED_PORT, GPIO_Pin_5);
#define LED0_OFF GPIO_SetBits(LED_PORT, GPIO_Pin_5);

#define LightSwitch1_ON GPIO_SetBits(GPIOA, GPIO_Pin_5);
#define LightSwitch1_OFF GPIO_ResetBits(GPIOA, GPIO_Pin_5);

#define LightSwitch0_ON GPIO_SetBits(GPIOA, GPIO_Pin_6);
#define LightSwitch0_OFF GPIO_ResetBits(GPIOA, GPIO_Pin_6);

#endif
