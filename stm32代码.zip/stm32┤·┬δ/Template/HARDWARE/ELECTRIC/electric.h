#ifndef __ELECTRIC_H
#define __ELECTRIC_H
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
void relay_init(void);
void relay1_on(void);
void relay1_off(void);
void relay2_on(void);
void relay2_off(void);
void relay3_on(void);
void relay3_off(void);
void relay4_on(void);
void relay4_off(void);


#endif
