#include <string.h>
#include "stm32f10x.h"  
#include "led.h"
#include "delay.h"
#include "usart.h" 
#include "wifi.h"
#include "timer.h"
#include "dht11.h"
#include "stdio.h"
#include "string.h"
#include "electric.h"
#include "beep.h"
#include "key.h"
#include "adc.h"
#include "lsens.h"

extern int Usart1_dht11;
int main(void) 
{
 
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);   //����NVIC�жϷ���2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	Usart1_Init(115200);
	Usart2_Init(115200);
	LED_Init();
	Delay_Init();
	DHT11_Init();
	relay_init();
	BEEP_Init();         	//��ʼ���������˿�
	KEY_Init();         	//��ʼ���밴�����ӵ�Ӳ���ӿ�
	USART1TxStr("this is wifi test!!!\r\n");
	USART2TxStr("this is wifi test!!!\r\n");
	

	BEEP=!BEEP;
	WIFI_Init();
	BEEP=!BEEP;
	Lsens_Init();
	
	TIM3_PWM_Init(7199,719);
  TIM4_Init(49,7199);//500ms
	while(1)                        //��ѭ��
	{
	  
	vu8 key=0;		
	u8 temperature;  	    
	u8 humidity; 
	float temp,humi,adcx;;
		Delay_Ms(1000);
		if(	Usart1_dht11==1)
			{
		
			DHT11_Read_Data(&temperature,&humidity);
			temp=(float)temperature*1.0;
			humi=(float)humidity*1.0;
			adcx=Lsens_Get_Val();	
				
			Client_Pubscribe(temp);
			Client_Pubscribe1(humi);
			Client_Pubscribe2(adcx);	
			Usart1_dht11=0;
		  }
		wait_SUB();
		CLR_Buf2();
		

	}
}

